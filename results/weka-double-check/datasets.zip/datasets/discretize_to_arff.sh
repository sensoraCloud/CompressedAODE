export CLASSPATH=/opt/weka/weka.jar;

#version for very large data set, it feature selection with CFs and then with wrapper
#csv_file=$(basename $1 .arff).orig_arff_file=$1;
orig_arff_file=$1;
arff_file=gc_$1;
discr_file=discr_$1;
feat_sel_file=feat_sel_$1;
feat_sel2_file=feat_sel2_$1;
obfusc_file=obfusc_$1
miss_replaced_file=miss_replaced_$1;

#replace missing values and perform unsupervised discretization
java -Xmx2500m weka.filters.unsupervised.attribute.ReplaceMissingValues -i $orig_arff_file -o $miss_replaced_file;
java -Xmx2500m weka.filters.unsupervised.attribute.Discretize -F -B 4 -M -1.0 -R first-last -i $miss_replaced_file -o $discr_file;

#CFS
#java -Xmx2500m  weka.filters.supervised.attribute.AttributeSelection -E "weka.attributeSelection.CfsSubsetEval " -S "weka.attributeSelection.BestFirst -D 1 -N 5"  -i $discr_file -o $feat_sel_file -c last;
#WRAPPER
#java -Xmx2500m weka.filters.supervised.attribute.AttributeSelection -E "weka.attributeSelection.WrapperSubsetEval -B weka.classifiers.bayes.NaiveBayes -F 5 -T 0.01 -R 1 --" -S "weka.attributeSelection.BestFirst -D 1 -N 5" -i $feat_sel_file -o $feat_sel2_file -c last;

#obfuscate the names
#java -Xmx2500m weka.filters.unsupervised.attribute.Obfuscate  -i $discr_file -o $obfusc_file;


#form1_file=form1_$1;
#form2_file=form2_$1;
#remove the V
#sed s/V//g $obfusc_file>$form1_file;
#remove the category declarations and replace with numeric 
#sed s/[{].*[}]/numeric/g $form1_file > $form2_file;

#finally export as csv
#java  -Xmx2500m weka.core.converters.CSVSaver  -i $form2_file -o $(basename $orig_arff_file .arff).csv ;

rm -f $form1_file $form2_file $miss_replaced_file $feat_sel2_file $arff_file;
